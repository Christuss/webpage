Na mizuuuuuuuuuuu??!
first fps game.exe fáljt kell futtatni és megy is a játék! 
Note: Alt + F4 a kilépés jelenleg. :(